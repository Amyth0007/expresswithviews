blogs = [
  {
    title: "How to get started with Js",
    content: "This is Js",
    slug:"python-learn"
  },
  {
    title: "How to get started with Python",
    content: "This is Python",
    slug:"python-django-learn"
  },
  {
    title: "How to get started with Django",
    content: "This is Django",
    slug:"django-learn"
  },
  {
    title: "How to get started with Css",
    content: "This is Css",
    slug:"Css learn"
  },
]

module.exports = blogs;
